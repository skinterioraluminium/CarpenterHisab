package com.skinterior.carpenterhisab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.room.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "jobs")
data class Job(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val customer: String,
    val agreedAmount: Double,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "entries",
    foreignKeys = [ForeignKey(entity = Job::class, parentColumns = ["id"], childColumns = ["jobId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("jobId")]
)
data class Entry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val jobId: Long,
    val type: String, // MATERIAL, LABOUR, OTHER, PAYMENT
    val title: String,
    val amount: Double,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface HisabDao {
    @Query("SELECT * FROM jobs ORDER BY createdAt DESC")
    fun jobs(): kotlinx.coroutines.flow.Flow<List<Job>>

    @Query("SELECT * FROM entries WHERE jobId = :jobId ORDER BY createdAt DESC")
    fun entries(jobId: Long): kotlinx.coroutines.flow.Flow<List<Entry>>

    @Insert suspend fun addJob(job: Job)
    @Insert suspend fun addEntry(entry: Entry)
    @Delete suspend fun deleteJob(job: Job)
}

@Database(entities = [Job::class, Entry::class], version = 1, exportSchema = false)
abstract class HisabDb : RoomDatabase() {
    abstract fun dao(): HisabDao
    companion object {
        @Volatile private var INSTANCE: HisabDb? = null
        fun get(context: android.content.Context): HisabDb =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(context.applicationContext, HisabDb::class.java, "carpenter_hisab.db")
                    .build().also { INSTANCE = it }
            }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = HisabDb.get(this).dao()
        setContent { CarpenterApp(dao) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CarpenterApp(dao: HisabDao) {
    val scope = rememberCoroutineScope()
    val jobs by dao.jobs().collectAsState(initial = emptyList())
    var selected by remember { mutableStateOf<Job?>(null) }
    var showJob by remember { mutableStateOf(false) }
    var showEntry by remember { mutableStateOf(false) }
    var bangla by remember { mutableStateOf(true) }
    val title = if (bangla) "কার্পেন্টার হিসাব" else "Carpenter Hisab"
    val selectedEntries by (selected?.let { dao.entries(it.id) }
        ?: kotlinx.coroutines.flow.flowOf(emptyList())).collectAsState(initial = emptyList())

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF9A6B19))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column { Text(title, fontWeight = FontWeight.Bold); Text("SK Interior & Aluminium", style = MaterialTheme.typography.labelSmall) } },
                    actions = { TextButton(onClick = { bangla = !bangla }) { Text(if (bangla) "EN" else "বাংলা") } }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { if (selected == null) showJob = true else showEntry = true }) {
                    Text("+", style = MaterialTheme.typography.headlineMedium)
                }
            }
        ) { pad ->
            if (selected == null) {
                LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Text(if (bangla) "আপনার কাজের সারাংশ" else "Business overview", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(if (bangla) "প্রতিটি সাইটের হিসাব আলাদা রাখুন" else "Track every site separately")
                    }
                    item { SummaryCard(jobs.size, bangla) }
                    item { Button(onClick = { showJob = true }, modifier = Modifier.fillMaxWidth()) { Text(if (bangla) "নতুন কাজ / সাইট যোগ করুন" else "Add new job / site") } }
                    item { Text(if (bangla) "আপনার কাজের তালিকা" else "Your projects", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                    if (jobs.isEmpty()) item { Text(if (bangla) "এখনও কোনো কাজ যোগ করা হয়নি। + চাপ দিয়ে শুরু করুন।" else "No projects yet. Tap + to begin.") }
                    items(jobs) { job ->
                        Card(onClick = { selected = job }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(job.name, fontWeight = FontWeight.Bold)
                                Text("${if (bangla) "কাস্টমার" else "Customer"}: ${job.customer}")
                                Text("${if (bangla) "চুক্তির টাকা" else "Agreed amount"}: ${money(job.agreedAmount)}")
                            }
                        }
                    }
                }
            } else {
                val costs = selectedEntries.filter { it.type != "PAYMENT" }.sumOf { it.amount }
                val paid = selectedEntries.filter { it.type == "PAYMENT" }.sumOf { it.amount }
                val material = selectedEntries.filter { it.type == "MATERIAL" }.sumOf { it.amount }
                val labour = selectedEntries.filter { it.type == "LABOUR" }.sumOf { it.amount }
                val other = selectedEntries.filter { it.type == "OTHER" }.sumOf { it.amount }
                val profit = selected!!.agreedAmount - costs
                LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        TextButton(onClick = { selected = null }) { Text("← ${if (bangla) "সব কাজ" else "All projects"}") }
                        Text(selected!!.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("${if (bangla) "কাস্টমার" else "Customer"}: ${selected!!.customer}")
                    }
                    item { Metric("চুক্তির টাকা / Contract", selected!!.agreedAmount) }
                    item { Metric("মোট মাল খরচ / Materials", material) }
                    item { Metric("মোট লেবার / Labour", labour) }
                    item { Metric("অন্যান্য খরচ / Other", other) }
                    item { Metric("মোট খরচ / Total cost", costs) }
                    item { Metric("কাস্টমারের কাছ থেকে পেয়েছেন / Received", paid) }
                    item { Metric("বাকি টাকা / Due", (selected!!.agreedAmount - paid).coerceAtLeast(0.0)) }
                    item {
                        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if (profit >= 0) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer)) {
                            Column(Modifier.padding(16.dp)) {
                                Text(if (profit >= 0) "আনুমানিক লাভ / Estimated profit" else "লোকসান / Loss", fontWeight = FontWeight.Bold)
                                Text(money(kotlin.math.abs(profit)), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    item { Button(onClick = { showEntry = true }, modifier = Modifier.fillMaxWidth()) { Text(if (bangla) "খরচ / পেমেন্ট যোগ করুন" else "Add cost / payment") } }
                    item { Text(if (bangla) "লেনদেনের তালিকা" else "Transactions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                    if (selectedEntries.isEmpty()) item { Text(if (bangla) "এখনও কোনো হিসাব নেই।" else "No entries yet.") }
                    items(selectedEntries) { e ->
                        ListItem(
                            headlineContent = { Text(e.title) },
                            supportingContent = { Text("${e.type} • ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(e.createdAt))}${if (e.note.isNotBlank()) " • ${e.note}" else ""}") },
                            trailingContent = { Text((if (e.type == "PAYMENT") "+" else "-") + money(e.amount), fontWeight = FontWeight.Bold) }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    if (showJob) JobDialog(bangla, onDismiss = { showJob = false }) { name, customer, amount ->
        scope.launch { dao.addJob(Job(name = name, customer = customer, agreedAmount = amount)) }
        showJob = false
    }
    if (showEntry && selected != null) EntryDialog(bangla, onDismiss = { showEntry = false }) { type, titleText, amount, note ->
        scope.launch { dao.addEntry(Entry(jobId = selected!!.id, type = type, title = titleText, amount = amount, note = note)) }
        showEntry = false
    }
}

@Composable
fun SummaryCard(count: Int, bangla: Boolean) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(if (bangla) "চলমান / মোট প্রজেক্ট" else "Total projects")
            Text(count.toString(), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text(if (bangla) "প্রজেক্ট খুলে বিস্তারিত লাভ-লোকসান দেখুন" else "Open a project to see its full accounts")
        }
    }
}

@Composable
fun Metric(label: String, amount: Double) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, modifier = Modifier.weight(1f))
            Text(money(amount), fontWeight = FontWeight.Bold)
        }
    }
}

fun money(v: Double) = "₹" + String.format(Locale("en", "IN"), "%,.2f", v)

@Composable
fun JobDialog(bangla: Boolean, onDismiss: () -> Unit, onSave: (String, String, Double) -> Unit) {
    var name by remember { mutableStateOf("") }
    var customer by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (bangla) "নতুন কাজ যোগ করুন" else "Add new project") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(if (bangla) "কাজ / সাইটের নাম" else "Project / site name") })
                OutlinedTextField(customer, { customer = it }, label = { Text(if (bangla) "কাস্টমারের নাম" else "Customer name") })
                OutlinedTextField(amount, { amount = it }, label = { Text(if (bangla) "মোট চুক্তির টাকা (₹)" else "Agreed amount (₹)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            }
        },
        confirmButton = { TextButton(enabled = name.isNotBlank() && amount.toDoubleOrNull() != null, onClick = { onSave(name.trim(), customer.trim(), amount.toDouble()) }) { Text(if (bangla) "সেভ" else "Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(if (bangla) "বাতিল" else "Cancel") } }
    )
}

@Composable
fun EntryDialog(bangla: Boolean, onDismiss: () -> Unit, onSave: (String, String, Double, String) -> Unit) {
    var type by remember { mutableStateOf("MATERIAL") }
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val labels = listOf("MATERIAL", "LABOUR", "OTHER", "PAYMENT")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (bangla) "হিসাব যোগ করুন" else "Add transaction") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(if (bangla) "হিসাবের ধরন" else "Entry type", fontWeight = FontWeight.Bold)
                labels.forEach { item ->
                    Row {
                        RadioButton(selected = type == item, onClick = { type = item })
                        Text(when (item) {
                            "MATERIAL" -> if (bangla) "মাল / Material" else "Material"
                            "LABOUR" -> if (bangla) "লেবার / Labour" else "Labour"
                            "OTHER" -> if (bangla) "অন্যান্য খরচ / Other" else "Other expense"
                            else -> if (bangla) "কাস্টমারের পেমেন্ট / Payment received" else "Payment received"
                        }, modifier = Modifier.padding(top = 12.dp))
                    }
                }
                OutlinedTextField(title, { title = it }, label = { Text(if (bangla) "বিবরণ (যেমন: অ্যালুমিনিয়াম)" else "Description") })
                OutlinedTextField(amount, { amount = it }, label = { Text(if (bangla) "টাকার পরিমাণ (₹)" else "Amount (₹)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(note, { note = it }, label = { Text(if (bangla) "নোট (ঐচ্ছিক)" else "Note (optional)") })
            }
        },
        confirmButton = { TextButton(enabled = title.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0, onClick = { onSave(type, title.trim(), amount.toDouble(), note.trim()) }) { Text(if (bangla) "সেভ" else "Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(if (bangla) "বাতিল" else "Cancel") } }
    )
}
