# Carpenter Hisab – Android Source

এটি SK Interior & Aluminium-এর জন্য একটি offline-first Android হিসাব অ্যাপের MVP source project।

## কী কী আছে
- প্রতিটি কাজ / সাইট আলাদা করে যোগ করা
- কাস্টমারের নাম ও মোট চুক্তির টাকা
- Material, Labour, Other expense এবং Payment received এন্ট্রি
- মোট খরচ, মোট পেমেন্ট, বাকি টাকা এবং আনুমানিক লাভ/লোকসান
- Room database-এ ফোনে offline হিসাব সংরক্ষণ
- বাংলা / English UI toggle

## APK তৈরি (মোবাইল থেকেই)
1. GitHub-এ একটি নতুন repository খুলুন: `CarpenterHisab`
2. এই ZIP-এর সব ফাইল repository-তে upload করুন।
3. GitHub repository-র **Actions** tab খুলুন।
4. **Build CarpenterHisab APK** workflow নির্বাচন করে **Run workflow** চাপুন।
5. Build শেষ হলে workflow run-এর নিচে **Artifacts** থেকে `CarpenterHisab-debug-apk` download করুন।
6. ZIP extract করে `app-debug.apk` ফোনে install করুন। Android চাইলে “Install unknown apps” অনুমতি দিন।

## হিসাবের সূত্র
- মোট খরচ = Material + Labour + Other
- বাকি = চুক্তির টাকা − কাস্টমারের কাছ থেকে পাওয়া টাকা (সর্বনিম্ন ০)
- আনুমানিক লাভ/লোকসান = চুক্তির টাকা − মোট খরচ

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি প্রথম MVP source; এখানে APK আগে থেকে compile করা নেই। Cloud backup, PDF/Excel report, edit/delete transaction, worker-wise attendance, stock, advance-to-supplier এবং GST module পরের সংস্করণে যোগ করা যাবে। এই সংস্করণে ডেটা ফোনের local database-এ থাকে—অ্যাপ uninstall বা ফোন নষ্ট হলে backup ছাড়া ডেটা হারাতে পারে। Build করার আগে GitHub Actions-এ প্রথমবার Android SDK setup সম্পন্ন হতে হবে।
